//////////////////////////////////////////////////////////////////
//Name: Kendrick Nguyen
//Professor: Shannon Cleary
//Class: CECS 275
//Company: CSULB
//Date: 29 January 2021
//////////////////////////////////////////////////////////////////

#include <iostream>
#include <cstdlib> //random number function
#include <ctime> //allows different random numbers
#include "CheckInput.h" //allows input to be checked, made by professor
using namespace std;//gets rid of the need to put ::std
#define ROWS 5 //add rows
#define COLS 5 //add columns

char map[ROWS][COLS]= {{ '~', '~', '~', '~', '~'},              //Created two 2D arrays for a solution and a displayBoard
                        {'~', '~', '~', '~', '~'},
                        {'~', '~', '~', '~', '~'},
                        {'~', '~', '~', '~', '~'},
                        {'~', '~', '~', '~', '~'}};
char mapSolution[ROWS][COLS]= {{ '~', '~', '~', '~', '~'}, 
                                {'~', '~', '~', '~', '~'},
                                {'~', '~', '~', '~', '~'},
                                {'~', '~', '~', '~', '~'},
                                {'~', '~', '~', '~', '~'}};

int placeShip(char mapSolution[ROWS][COLS]){
  srand(time(NULL));
  int shipRow = rand() % 4; //Random number generator location for the Ship's row
  int shipCol = rand() % 4; //Random number generator location for the Ship's column
  mapSolution[shipRow][shipCol] = '*';     // This let's us place the ship onto the map
  mapSolution[shipRow][shipCol+1] = '*';
  mapSolution[shipRow+1][shipCol] = '*';
  mapSolution[shipRow+1][shipCol+1] = '*';
  return 0;
}

void displayBoard(char map[ROWS][COLS]){ //Whole function's purpose is to display the current state of the board to the user
  int n = 0;
  char letters[5] = { 'A', 'B', 'C', 'D', 'E'};
  cout<< "  1 2 3 4 5"<<endl;
  for(int i = 0; i <ROWS; i++){     //Displays the board using a nested for loop
    cout<< letters[n]<<" ";
    n+=1;
    for(int j = 0; j<COLS; j++){
      cout<< map[i][j]<<" ";
    }
    cout<<endl;
  }
}

int getRow(){
  string rowIn;                     //Created string input so that the function .length can be used
  cout<< "Enter in a Row (A-E): ";  //Output for user to see
  while(1){
    cin>>rowIn;                     //user input
    if (rowIn.length() == 1){       //User enters one letter, if not, an Invalid statement is returned
      if(rowIn.compare("a") == 0){  //returns row location 0 back
        return 0;
      }
      if (rowIn.compare("A") == 0){ //returns row location 0 back
        return 0;
      }
      if(rowIn.compare("b") == 0){  //returns row location 1 back
        return 1;
      }
      if (rowIn.compare("B") == 0){ //returns row location 1 back
        return 1; 
      }
      if(rowIn.compare("c") == 0){  //returns row location 2 back
        return 2;
      }
      if (rowIn.compare("C") == 0){ //returns row location 2 back
        return 2;
      }
      if(rowIn.compare("d") == 0){  //returns row location 3 back
        return 3;
      }
      if (rowIn.compare("D") == 0){ //returns row location 3 back
        return 3;
      }
      if(rowIn.compare("e") == 0){  //returns row location 4 back
        return 4;
      }
      if (rowIn.compare("E") == 0){ //returns row location 4 back
        return 4;
      }
    }else{
      cout<<"Invalid input, please try again: ";
    }
  }
}

int getCol(){
  int colIn;
  cout<< "Enter in a Column (1-5): ";       //Simpler than getRol() because all you need returned are integers
  while(1){
    colIn = getIntRange(1,5);               //Use Checkinput to make it so that users can only have a few specified options
    if(colIn == 1){
      return 0;                             //Returns 0 fireShot() and then breaks
    }
    if(colIn == 2){
      return 1;
    }
    if(colIn == 3){
      return 2;
    }
    if(colIn == 4){
      return 3;
    }
    if(colIn == 5){
      return 4;
    }
  }
}

int fireShot(char map[ROWS][COLS], char hitboard[ROWS][COLS]){
  int shotHit = 0;                                                //Init variable
  while(1){
    displayBoard(map);                                            //Shows the board to the user every loop
    int row = getRow();                                           //Gets value from getRow to manipulate the array
    int col = getCol();                                           //Gets value from getCol to manipulate the array
    if (map[row][col] == '~'){                                    //No repeat values
      if (hitboard[row][col] == '*'){                             //If mapSolution has * on that index, displays~
        map[row][col] = '*';                                      //~the same on the board
        cout<< "HIT!"<<endl;
        shotHit+=1;                                               //Increase tally for shots hit
      }else{
        map[row][col]='x';                                        //If there is no *, displays x for miss
        cout<<"Miss!"<<endl;
      }
    }else{
      cout<<"You have already shot at this area, please try again."<<endl;
    }
    if (shotHit == 4){                                            //Once user hits all *, ends program
      displayBoard(map);
      cout<<"You sunk my battle ship!"<<endl;
      for(int i = 0; i <ROWS; i++){                               //Displays the board using a nested for loop
        for(int j = 0; j<COLS; j++){
          map[i][j]='~';
          hitboard[i][j]='~';
        }
      }
      return 1;
    }
  }
}

int menu(){
  while (1){
    int fire = 0;                       //Initialize the variable
    cout << "Menu:" <<endl;
    cout << "1. Fire Shot"<<endl;
    cout << "2. Quit" <<endl; 
    fire = getIntRange(1,2);            //Use checkInput to make sure user only has two options~
    if (fire == 1){                     //~if not they would recieve an Invalid and have to try again
      fireShot(map, mapSolution);       //Calls the fireshot Function if user inputs 1
      break;
    }
    if (fire == 2){
      cout<<"You have quit the game.";  //Ends the program if user selects Quit
      return 0;
    }
    cout<<endl;
  }
  return 0;
}

int main(){                   //Use main just to call the menu and run displayBoard and placeShip
  while(1){
    displayBoard(map);       //Displays the board for the user initially
    placeShip(mapSolution);  //Creates the solution map
    menu();                  //Calls the main function
  }
}